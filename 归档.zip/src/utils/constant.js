/* eslint-disable import/prefer-default-export */
export const PAY_TYPE = {
  wechat: 1,
  alipay: 2,
};

export const BUY_MEMBER = {
  yes: 1,
  no: 0, // 默认否
}