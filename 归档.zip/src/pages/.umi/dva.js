import dva from 'dva';
import { Component } from 'react';
import createLoading from 'dva-loading';
import history from '@tmp/history';

let app = null;

export function _onCreate() {
  const plugins = require('umi/_runtimePlugin');
  const runtimeDva = plugins.mergeConfig('dva');
  app = dva({
    history,
    
    ...(runtimeDva.config || {}),
    ...(window.g_useSSR ? { initialState: window.g_initialData } : {}),
  });
  
  app.use(createLoading());
  (runtimeDva.plugins || []).forEach(plugin => {
    app.use(plugin);
  });
  
  app.model({ namespace: 'banner', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/banner.js').default) });
app.model({ namespace: 'charge', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/charge.js').default) });
app.model({ namespace: 'global', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/global.js').default) });
app.model({ namespace: 'order', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/order.js').default) });
app.model({ namespace: 'pbanner', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/pbanner.js').default) });
app.model({ namespace: 'phone', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/phone.js').default) });
app.model({ namespace: 'phoneForm', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/phoneForm.js').default) });
app.model({ namespace: 'prePay', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/prePay.js').default) });
app.model({ namespace: 'productDetail', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/productDetail.js').default) });
app.model({ namespace: 'products', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/products.js').default) });
app.model({ namespace: 'recommed', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/recommed.js').default) });
app.model({ namespace: 'seckill', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/seckill.js').default) });
app.model({ namespace: 'user', ...(require('/Users/xufengyu/Desktop/11/12/ants2-app/src/models/user.js').default) });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
