import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__common" */ '../../layouts/common'),
        })
      : require('../../layouts/common').default,
    routes: [
      {
        path: '/login',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__login" */ '../login'),
            })
          : require('../login').default,
        title: '盎司登陆',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '盎司登陆',
        _title_default: '盎司一起',
      },
      {
        path: '/topup',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__topup" */ '../topup'),
            })
          : require('../topup').default,
        backgroundColor: 'gray',
        hasNavBar: false,
        exact: true,
        _title: '盎司一起',
        _title_default: '盎司一起',
      },
      {
        path: '/topup/temp',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__topup__temp" */ '../topup/temp'),
            })
          : require('../topup/temp').default,
        backgroundColor: 'gray',
        hasNavBar: false,
        exact: true,
        _title: '盎司一起',
        _title_default: '盎司一起',
      },
      {
        path: '/',
        type: 'tabBar',
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__home__models__home.js' */ '/Users/xufengyu/Desktop/11/12/ants2-app/src/pages/home/models/home.js').then(
                  m => {
                    return { namespace: 'home', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__home" */ '../home'),
            })
          : require('../home').default,
        title: '首页',
        hasNavBar: false,
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '首页',
        _title_default: '盎司一起',
      },
      {
        path: '/explore',
        type: 'tabBar',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__explore" */ '../explore'),
            })
          : require('../explore').default,
        title: '发现',
        backgroundColor: 'gray',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '发现',
        _title_default: '盎司一起',
      },
      {
        path: '/orders',
        type: 'tabBar',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__orders" */ '../orders'),
            })
          : require('../orders').default,
        backgroundColor: 'gray',
        footer: false,
        title: '订单',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '订单',
        _title_default: '盎司一起',
      },
      {
        path: '/my',
        type: 'tabBar',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import(/* webpackChunkName: "p__my" */ '../my'),
            })
          : require('../my').default,
        title: '我的',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '我的',
        _title_default: '盎司一起',
      },
      {
        path: '/charge',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__charge" */ '../charge'),
            })
          : require('../charge').default,
        backgroundColor: 'gray',
        title: '充值成功',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '充值成功',
        _title_default: '盎司一起',
      },
      {
        path: '/orderdetail',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__orderdetail" */ '../orderdetail'),
            })
          : require('../orderdetail').default,
        backgroundColor: 'gray',
        title: '订单详情',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '订单详情',
        _title_default: '盎司一起',
      },
      {
        path: '/phone',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__phone" */ '../phone'),
            })
          : require('../phone').default,
        backgroundColor: 'gray',
        title: '话费充值',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '话费充值',
        _title_default: '盎司一起',
      },
      {
        path: '/seckill',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__seckill" */ '../seckill'),
            })
          : require('../seckill').default,
        backgroundColor: 'gray',
        title: '秒杀活动',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '秒杀活动',
        _title_default: '盎司一起',
      },
      {
        path: '/successbuy',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__successbuy" */ '../successbuy'),
            })
          : require('../successbuy').default,
        title: '购买成功',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '购买成功',
        _title_default: '盎司一起',
      },
      {
        path: '/memberrecharge',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__memberrecharge" */ '../memberrecharge'),
            })
          : require('../memberrecharge').default,
        backgroundColor: 'gray',
        title: '我的卡券包',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '我的卡券包',
        _title_default: '盎司一起',
      },
      {
        path: '/history',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__card__history" */ '../card/history'),
            })
          : require('../card/history').default,
        backgroundColor: 'white',
        title: '历史卡券',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '历史卡券',
        _title_default: '盎司一起',
      },
      {
        path: '/card',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__card" */ '../card'),
            })
          : require('../card').default,
        backgroundColor: 'white',
        title: '我的卡券',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '我的卡券',
        _title_default: '盎司一起',
      },
      {
        path: '/search',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__search" */ '../search'),
            })
          : require('../search').default,
        backgroundColor: 'white',
        title: '搜索',
        exact: true,
        Routes: [require('./TitleWrapper.jsx').default],
        _title: '搜索',
        _title_default: '盎司一起',
      },
      {
        component: () =>
          React.createElement(
            require('/Users/xufengyu/Desktop/11/12/ants2-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
        _title: '盎司一起',
        _title_default: '盎司一起',
      },
    ],
    _title: '盎司一起',
    _title_default: '盎司一起',
  },
  {
    component: () =>
      React.createElement(
        require('/Users/xufengyu/Desktop/11/12/ants2-app/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
    _title: '盎司一起',
    _title_default: '盎司一起',
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return <Router history={history}>{renderRoutes(routes, props)}</Router>;
  }
}
