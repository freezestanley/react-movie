export { default as ProductInfo } from './ProductInfo';
export { default as ProductHead } from './ProductHead';