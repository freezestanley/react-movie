import React from 'react';
import styles from './index.less';
export default ()=>{
  return(
    <div className ={styles.cardcharge}>
      <div>
        <span>腾讯视频会员</span>
        <span> 有效期至：2020-04-02</span>
      </div>
      <div> 激活方式：请通过"订单详情"页面点击链接备份激活方式：请通过"订单详情"页面点击链接备份</div>
      <div>
        <span>卡号</span>
        <span>83838375956607</span>
        <span>复制</span>
      </div>
      <div>
        <span>卡密</span>
        <span>83838375956607</span>
        <span>复制</span>
      </div>
    </div>
  )
}